package model.cell;

public class EmptyCell implements Cell{

  @Override
  public String textualPrint() {
    return "_";
  }
}
