Demonstration of the real Queen's Blood game: https://www.youtube.com/watch?v=TpeQ3bEc8K4


