package model;

/**
 * Enum representing the two possible player colors in the game.
 */
public enum PlayerColor {
  RED, BLUE
}